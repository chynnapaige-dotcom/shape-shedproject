import React from "react";
import { Link } from "react-router-dom";
import RevealOnScroll from "../shared/RevealOnScroll";

export default function CTASection() {
  return (
    <section className="py-24 lg:py-32 bg-accent text-accent-foreground">
      <div className="max-w-4xl mx-auto px-6 lg:px-10 text-center">
        <RevealOnScroll>
          <p className="font-body text-xs tracking-[0.3em] uppercase text-accent-foreground/60 mb-4">
            Ready to Begin?
          </p>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-semibold leading-tight mb-6">
            Your Confidence Journey
            <br />
            <span className="italic">Starts Here</span>
          </h2>
          <p className="font-body text-base text-accent-foreground/70 max-w-lg mx-auto mb-10 leading-relaxed">
            Schedule a free consultation to learn about our body contouring
            services and create a personalized plan that fits your goals.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center font-body text-sm font-medium bg-background text-foreground rounded-full px-10 py-4 hover:bg-background/90 transition-all duration-300 shadow-lg"
          >
            Request a Consultation
          </Link>
        </RevealOnScroll>
      </div>
    </section>
  );
}