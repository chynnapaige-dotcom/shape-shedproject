import React from "react";
import { Link } from "react-router-dom";
import { Zap, Heart, MessageCircle } from "lucide-react";
import SectionHeading from "../shared/SectionHeading";
import RevealOnScroll from "../shared/RevealOnScroll";

const services = [
  {
    title: "Emslim Abs",
    description:
      "Strengthen and tone your core with non-invasive muscle stimulation technology. Equivalent to thousands of crunches in a single 30-minute session.",
    icon: Zap,
    image: "https://media.base44.com/images/public/user_69ea6b532f35d3933185bec1/a8d4ea32b_max5.jpg",
  },
  {
    title: "Emslim Glutes",
    description:
      "Lift and sculpt your glutes naturally. Our advanced body contouring technology helps build muscle and define curves without surgery or downtime.",
    icon: Heart,
    image: "https://media.base44.com/images/public/user_69ea6b532f35d3933185bec1/99bd3f88e_glute.jpg",
  },
  {
    title: "Consultation",
    description:
      "Start with a personalized consultation to discuss your goals, learn about our services, and create a custom plan tailored to your body and lifestyle.",
    icon: MessageCircle,
    image: "https://media.base44.com/images/public/user_69ea6b532f35d3933185bec1/089c07195_machine.jpg",
  },
];

export default function FeaturedServicesSection() {
  return (
    <section className="py-24 lg:py-32 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <SectionHeading
          label="Our Services"
          title="The Performance Suite"
          description="Advanced non-invasive body contouring services designed to help you look and feel your best."
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, i) => (
            <RevealOnScroll key={service.title} delay={i * 0.15}>
              <div className="group bg-background rounded-[2rem] overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500">
                <div className="aspect-[4/3] overflow-hidden">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                </div>
                <div className="p-8">
                  <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center mb-4">
                    <service.icon className="w-5 h-5 text-accent" />
                  </div>
                  <h3 className="font-heading text-xl font-semibold text-foreground mb-3">
                    {service.title}
                  </h3>
                  <p className="font-body text-sm text-muted-foreground leading-relaxed">
                    {service.description}
                  </p>
                </div>
              </div>
            </RevealOnScroll>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link
            to="/services"
            className="inline-flex font-body text-sm font-medium text-accent border-b border-accent pb-1 hover:text-accent/70 transition-colors"
          >
            View All Services →
          </Link>
        </div>
      </div>
    </section>
  );
}