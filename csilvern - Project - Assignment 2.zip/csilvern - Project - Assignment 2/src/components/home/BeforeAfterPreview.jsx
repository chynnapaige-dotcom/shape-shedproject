import React from "react";
import { Link } from "react-router-dom";
import SectionHeading from "../shared/SectionHeading";
import RevealOnScroll from "../shared/RevealOnScroll";

const results = [
  {
    image: "https://media.base44.com/images/public/user_69ea6b532f35d3933185bec1/452635969_beforeafter1.jpg",
    label: "Abs Contouring",
  },
  {
    image: "https://media.base44.com/images/public/user_69ea6b532f35d3933185bec1/444df2a3e_beforeafter2.jpg",
    label: "Core Toning",
  },
  {
    image: "https://media.base44.com/images/public/user_69ea6b532f35d3933185bec1/3d95991e8_beforeafter3.jpg",
    label: "Body Sculpting",
  },
];

export default function BeforeAfterPreview() {
  return (
    <section className="py-24 lg:py-32">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <SectionHeading
          label="Real Results"
          title="Real Progress, Real People"
          description="See the transformative results our clients have experienced. Individual results may vary."
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {results.map((result, i) => (
            <RevealOnScroll key={result.label} delay={i * 0.15}>
              <div className="relative rounded-[2rem] overflow-hidden border border-secondary group">
                <img
                  src={result.image}
                  alt={`${result.label} before and after`}
                  className="w-full aspect-[3/4] object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-foreground/60 to-transparent p-6">
                  <p className="font-body text-sm text-background font-medium">
                    {result.label}
                  </p>
                </div>
              </div>
            </RevealOnScroll>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link
            to="/before-after"
            className="inline-flex font-body text-sm font-medium text-accent border-b border-accent pb-1 hover:text-accent/70 transition-colors"
          >
            View Full Gallery →
          </Link>
        </div>
      </div>
    </section>
  );
}