import React from "react";
import SectionHeading from "../shared/SectionHeading";
import RevealOnScroll from "../shared/RevealOnScroll";

export default function VideoSection() {
  return (
    <section className="py-24 lg:py-32">
      <div className="max-w-5xl mx-auto px-6 lg:px-10">
        <SectionHeading
          label="Featured Video"
          title="See the Experience"
          description="Learn more about Shape Shed and how non-invasive body contouring can support your wellness goals."
        />

        <RevealOnScroll>
          <div className="relative rounded-[2rem] overflow-hidden border border-secondary shadow-lg">
            <div className="aspect-video">
              <video
                controls
                className="w-full h-full object-cover"
                poster="https://media.base44.com/images/public/user_69ea6b532f35d3933185bec1/089c07195_machine.jpg"
              >
                <source
                  src="https://www.w3schools.com/html/mov_bbb.mp4"
                  type="video/mp4"
                />
                Your browser does not support the video tag.
              </video>
            </div>
          </div>
          <p className="font-heading text-base italic text-primary text-center mt-6">
            "Confidence is the best thing you can wear." — Shape Shed
          </p>
        </RevealOnScroll>
      </div>
    </section>
  );
}