import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";

export default function HeroSection({ heroImage }) {
  return (
    <section className="relative min-h-[90vh] flex items-center overflow-hidden">
      {/* Background image with parallax feel */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Shape Shed wellness environment"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/70 to-background/30" />
      </div>

      <div className="relative max-w-7xl mx-auto px-6 lg:px-10 py-20">
        <div className="max-w-xl">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="font-body text-xs tracking-[0.3em] uppercase text-primary mb-6"
          >
            Body Contouring &amp; Wellness
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="font-heading text-5xl sm:text-6xl lg:text-7xl font-semibold text-foreground leading-[1.1] mb-6"
          >
            Sculpt Your
            <br />
            <span className="text-primary italic">Confidence</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="font-body text-base sm:text-lg text-muted-foreground leading-relaxed mb-10 max-w-md"
          >
            Welcome to Shape Shed — a modern body contouring and wellness brand
            focused on helping you feel strong, confident, and informed.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="flex flex-wrap gap-4"
          >
            <Link
              to="/contact"
              className="inline-flex items-center font-body text-sm font-medium bg-accent text-accent-foreground rounded-full px-8 py-4 hover:bg-accent/90 transition-all duration-300 shadow-lg shadow-accent/20"
            >
              Request a Consultation
            </Link>
            <Link
              to="/services"
              className="inline-flex items-center font-body text-sm font-medium border border-foreground/20 text-foreground rounded-full px-8 py-4 hover:border-accent hover:text-accent transition-all duration-300"
            >
              Explore Services
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
}