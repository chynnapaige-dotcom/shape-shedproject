import React from "react";
import RevealOnScroll from "../shared/RevealOnScroll";

export default function AboutSection({ aboutImage }) {
  return (
    <section className="py-24 lg:py-32">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <RevealOnScroll>
            <div className="relative">
              <img
                src={aboutImage}
                alt="About Shape Shed"
                className="w-full rounded-[2rem] object-cover aspect-[4/3] shadow-xl"
              />
              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-secondary rounded-[2rem] -z-10" />
            </div>
          </RevealOnScroll>

          <RevealOnScroll delay={0.2}>
            <div>
              <p className="font-body text-xs tracking-[0.3em] uppercase text-primary mb-4">
                About Us
              </p>
              <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-semibold text-foreground leading-tight mb-6">
                Modern Wellness,
                <br />
                <span className="italic text-primary">Timeless Confidence</span>
              </h2>
              <p className="font-body text-base text-muted-foreground leading-relaxed mb-6">
                Shape Shed is a body contouring and wellness brand dedicated to
                helping clients feel their best — inside and out. We combine
                advanced non-invasive technology with a supportive, informative
                approach to wellness.
              </p>
              <p className="font-body text-base text-muted-foreground leading-relaxed mb-8">
                Whether you're a busy professional, a new mom, or simply
                investing in yourself, Shape Shed provides a calm and professional
                environment where your goals come first.
              </p>
              <div className="flex gap-12">
                <div>
                  <p className="font-heading text-3xl font-semibold text-accent">100%</p>
                  <p className="font-body text-xs text-muted-foreground mt-1">Non-Invasive</p>
                </div>
                <div>
                  <p className="font-heading text-3xl font-semibold text-accent">30</p>
                  <p className="font-body text-xs text-muted-foreground mt-1">Min Sessions</p>
                </div>
                <div>
                  <p className="font-heading text-3xl font-semibold text-accent">0</p>
                  <p className="font-body text-xs text-muted-foreground mt-1">Downtime</p>
                </div>
              </div>
            </div>
          </RevealOnScroll>
        </div>
      </div>
    </section>
  );
}