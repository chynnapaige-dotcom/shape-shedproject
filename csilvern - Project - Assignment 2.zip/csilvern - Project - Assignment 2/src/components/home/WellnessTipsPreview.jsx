import React from "react";
import { Link } from "react-router-dom";
import { Droplets, Salad, Activity } from "lucide-react";
import SectionHeading from "../shared/SectionHeading";
import RevealOnScroll from "../shared/RevealOnScroll";

const tips = [
  {
    title: "Hydration",
    description: "Staying well-hydrated supports skin elasticity, recovery, and overall wellness.",
    icon: Droplets,
  },
  {
    title: "Balanced Eating",
    description: "A nutrient-rich diet enhances your body contouring results and daily energy.",
    icon: Salad,
  },
  {
    title: "Movement",
    description: "Regular gentle movement keeps muscles active and supports long-term toning.",
    icon: Activity,
  },
];

export default function WellnessTipsPreview() {
  return (
    <section className="py-24 lg:py-32 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <SectionHeading
          label="Wellness Tips"
          title="Nourish Your Body"
          description="Simple daily habits that support your body contouring journey and overall well-being."
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {tips.map((tip, i) => (
            <RevealOnScroll key={tip.title} delay={i * 0.15}>
              <div className="bg-background rounded-[2rem] p-8 text-center shadow-sm hover:shadow-md transition-shadow duration-300">
                <div className="w-16 h-16 rounded-full bg-secondary flex items-center justify-center mx-auto mb-5">
                  <tip.icon className="w-7 h-7 text-accent" />
                </div>
                <h3 className="font-heading text-xl font-semibold text-foreground mb-3">
                  {tip.title}
                </h3>
                <p className="font-body text-sm text-muted-foreground leading-relaxed">
                  {tip.description}
                </p>
              </div>
            </RevealOnScroll>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link
            to="/wellness-tips"
            className="inline-flex font-body text-sm font-medium text-accent border-b border-accent pb-1 hover:text-accent/70 transition-colors"
          >
            Explore Wellness Tips →
          </Link>
        </div>
      </div>
    </section>
  );
}