import React from "react";
import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="bg-foreground text-background/80">
      <div className="max-w-7xl mx-auto px-6 lg:px-10 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* Brand */}
          <div>
            <img
              src="https://media.base44.com/images/public/user_69ea6b532f35d3933185bec1/a222da98b_logo.png"
              alt="Shape Shed Logo"
              className="h-14 w-14 rounded-full object-cover mb-4 brightness-200"
            />
            <h3 className="font-heading text-2xl text-background font-semibold mb-2">
              Shape Shed
            </h3>
            <p className="font-body text-sm leading-relaxed text-background/60 max-w-xs">
              A modern body contouring and wellness brand focused on confidence,
              self-care, and non-invasive body sculpting.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-heading text-lg text-background font-semibold mb-4">
              Quick Links
            </h4>
            <ul className="space-y-3 font-body text-sm">
              <li>
                <Link to="/" className="hover:text-primary transition-colors">Home</Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-primary transition-colors">Services</Link>
              </li>
              <li>
                <Link to="/before-after" className="hover:text-primary transition-colors">Before &amp; After</Link>
              </li>
              <li>
                <Link to="/wellness-tips" className="hover:text-primary transition-colors">Wellness Tips</Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-primary transition-colors">Contact</Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-heading text-lg text-background font-semibold mb-4">
              Get in Touch
            </h4>
            <div className="space-y-3 font-body text-sm">
              <p>
                <a
                  href="mailto:hello@shapeshed.com"
                  className="text-primary hover:text-primary/80 transition-colors text-base font-medium"
                >
                  hello@shapeshed.com
                </a>
              </p>
              <p className="text-background/60">Atlanta, GA</p>
              <p className="text-background/60">By Appointment Only</p>
            </div>
          </div>
        </div>

        <div className="border-t border-background/10 mt-12 pt-8 text-center">
          <p className="font-body text-xs text-background/40">
            © {new Date().getFullYear()} Shape Shed. All rights reserved. | Sculpt Your Confidence
          </p>
        </div>
      </div>
    </footer>
  );
}