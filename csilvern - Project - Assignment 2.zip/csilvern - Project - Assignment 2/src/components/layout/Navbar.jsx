import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X } from "lucide-react";

const navLinks = [
  { label: "Home", path: "/" },
  { label: "Services", path: "/services" },
  { label: "Before & After", path: "/before-after" },
  { label: "Wellness Tips", path: "/wellness-tips" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [location]);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-background/80 backdrop-blur-xl shadow-sm"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3">
            <img
              src="https://media.base44.com/images/public/user_69ea6b532f35d3933185bec1/a222da98b_logo.png"
              alt="Shape Shed Logo"
              className="h-12 w-12 rounded-full object-cover"
            />
            <div className="hidden sm:block">
              <span className="font-heading text-xl font-semibold text-foreground tracking-wide">
                Shape Shed
              </span>
              <p className="text-xs text-muted-foreground font-body tracking-widest uppercase">
                Sculpt Your Confidence
              </p>
            </div>
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`font-body text-sm tracking-wide transition-colors duration-300 ${
                  location.pathname === link.path
                    ? "text-accent font-medium"
                    : "text-foreground/70 hover:text-accent"
                }`}
              >
                {link.label}
              </Link>
            ))}
            <Link
              to="/contact"
              className="font-body text-sm tracking-wide border border-accent text-accent rounded-full px-6 py-2 hover:bg-accent hover:text-accent-foreground transition-all duration-300"
            >
              Contact
            </Link>
          </div>

          {/* Mobile toggle */}
          <button
            onClick={() => setOpen(!open)}
            className="md:hidden text-foreground p-2"
            aria-label="Toggle menu"
          >
            {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden bg-background/95 backdrop-blur-xl border-t border-border">
          <div className="px-6 py-6 space-y-4">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`block font-body text-base tracking-wide ${
                  location.pathname === link.path
                    ? "text-accent font-medium"
                    : "text-foreground/70"
                }`}
              >
                {link.label}
              </Link>
            ))}
            <Link
              to="/contact"
              className="block text-center font-body text-sm border border-accent text-accent rounded-full px-6 py-3 hover:bg-accent hover:text-accent-foreground transition-all"
            >
              Contact
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}