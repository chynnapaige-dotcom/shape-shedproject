import React from "react";

export default function SectionHeading({ label, title, description, align = "center" }) {
  const alignClass = align === "left" ? "text-left" : "text-center";

  return (
    <div className={`${alignClass} max-w-2xl ${align === "center" ? "mx-auto" : ""} mb-12`}>
      {label && (
        <p className="font-body text-xs tracking-[0.3em] uppercase text-primary mb-3">
          {label}
        </p>
      )}
      <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-semibold text-foreground leading-tight">
        {title}
      </h2>
      {description && (
        <p className="font-body text-base text-muted-foreground mt-4 leading-relaxed">
          {description}
        </p>
      )}
    </div>
  );
}