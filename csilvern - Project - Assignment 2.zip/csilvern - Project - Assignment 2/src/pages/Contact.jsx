import React, { useState } from "react";
import { Mail, Phone, MapPin, Send } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import SectionHeading from "../components/shared/SectionHeading";
import RevealOnScroll from "../components/shared/RevealOnScroll";
import { toast } from "sonner";

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
    toast.success("Thank you! Your consultation request has been received.");
  };

  return (
    <div>
      {/* Hero */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <SectionHeading
            label="Get in Touch"
            title="Request a Consultation"
            description="Ready to start your confidence journey? Fill out the form below and we'll be in touch to schedule your personalized consultation."
          />
        </div>
      </section>

      {/* Form + Contact info */}
      <section className="pb-24 lg:pb-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-16">
            {/* Contact info sidebar */}
            <div className="lg:col-span-2">
              <RevealOnScroll>
                <div className="bg-accent text-accent-foreground rounded-[2rem] p-8 lg:p-10">
                  <h3 className="font-heading text-2xl font-semibold mb-6">
                    Contact Information
                  </h3>
                  <p className="font-body text-sm text-accent-foreground/70 mb-8 leading-relaxed">
                    Have questions? Reach out directly or fill out the consultation form
                    and we'll get back to you within 24 hours.
                  </p>

                  <div className="space-y-6">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-full bg-accent-foreground/10 flex items-center justify-center flex-shrink-0">
                        <Mail className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="font-body text-xs text-accent-foreground/60 mb-1">Email</p>
                        <a
                          href="mailto:hello@shapeshed.com"
                          className="font-body text-sm hover:underline"
                        >
                          hello@shapeshed.com
                        </a>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-full bg-accent-foreground/10 flex items-center justify-center flex-shrink-0">
                        <Phone className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="font-body text-xs text-accent-foreground/60 mb-1">Phone</p>
                        <p className="font-body text-sm">(555) 123-4567</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-full bg-accent-foreground/10 flex items-center justify-center flex-shrink-0">
                        <MapPin className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="font-body text-xs text-accent-foreground/60 mb-1">Location</p>
                        <p className="font-body text-sm">Atlanta, GA</p>
                        <p className="font-body text-xs text-accent-foreground/60 mt-1">
                          By Appointment Only
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </RevealOnScroll>
            </div>

            {/* Form */}
            <div className="lg:col-span-3">
              <RevealOnScroll delay={0.2}>
                {submitted ? (
                  <div className="bg-secondary/40 rounded-[2rem] p-12 text-center">
                    <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-6">
                      <Send className="w-7 h-7 text-primary" />
                    </div>
                    <h3 className="font-heading text-2xl font-semibold text-foreground mb-3">
                      Thank You!
                    </h3>
                    <p className="font-body text-base text-muted-foreground max-w-sm mx-auto">
                      Your consultation request has been received. We'll be in touch
                      within 24 hours to schedule your appointment.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="fullName" className="font-body text-sm text-foreground">
                          Full Name *
                        </Label>
                        <Input
                          id="fullName"
                          required
                          placeholder="Jane Doe"
                          className="rounded-xl border-secondary bg-transparent font-body text-sm h-12 focus:border-primary"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email" className="font-body text-sm text-foreground">
                          Email Address *
                        </Label>
                        <Input
                          id="email"
                          type="email"
                          required
                          placeholder="jane@example.com"
                          className="rounded-xl border-secondary bg-transparent font-body text-sm h-12 focus:border-primary"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="phone" className="font-body text-sm text-foreground">
                          Phone Number *
                        </Label>
                        <Input
                          id="phone"
                          type="tel"
                          required
                          placeholder="(555) 123-4567"
                          className="rounded-xl border-secondary bg-transparent font-body text-sm h-12 focus:border-primary"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="interest" className="font-body text-sm text-foreground">
                          Area of Interest *
                        </Label>
                        <Select required>
                          <SelectTrigger className="rounded-xl border-secondary bg-transparent font-body text-sm h-12">
                            <SelectValue placeholder="Select a service" />
                          </SelectTrigger>
                          <SelectContent className="font-body">
                            <SelectItem value="emslim-abs">Emslim Abs</SelectItem>
                            <SelectItem value="emslim-glutes">Emslim Glutes</SelectItem>
                            <SelectItem value="consultation">General Consultation</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label className="font-body text-sm text-foreground">
                        Preferred Contact Method
                      </Label>
                      <RadioGroup defaultValue="email" className="flex gap-6 pt-1">
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="email" id="contact-email" />
                          <Label htmlFor="contact-email" className="font-body text-sm text-muted-foreground cursor-pointer">
                            Email
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="phone" id="contact-phone" />
                          <Label htmlFor="contact-phone" className="font-body text-sm text-muted-foreground cursor-pointer">
                            Phone
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="text" id="contact-text" />
                          <Label htmlFor="contact-text" className="font-body text-sm text-muted-foreground cursor-pointer">
                            Text
                          </Label>
                        </div>
                      </RadioGroup>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="goals" className="font-body text-sm text-foreground">
                        Questions or Goals
                      </Label>
                      <Textarea
                        id="goals"
                        placeholder="Tell us about your wellness goals or any questions you have..."
                        className="rounded-xl border-secondary bg-transparent font-body text-sm min-h-[120px] resize-none focus:border-primary"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full font-body text-sm font-medium bg-accent text-accent-foreground rounded-full py-4 hover:bg-accent/90 transition-all duration-300 shadow-lg shadow-accent/20"
                    >
                      Submit Consultation Request
                    </button>

                    <p className="font-body text-xs text-muted-foreground text-center">
                      This form is for demonstration purposes only and does not submit data.
                    </p>
                  </form>
                )}
              </RevealOnScroll>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}