import React from "react";
import { Droplets, Salad, Activity, ExternalLink } from "lucide-react";
import SectionHeading from "../components/shared/SectionHeading";
import RevealOnScroll from "../components/shared/RevealOnScroll";

const tips = [
  {
    title: "Hydration",
    icon: Droplets,
    description:
      "Water is essential for every function in your body — from digestion to skin health. Proper hydration supports muscle recovery after body contouring sessions and helps maintain skin elasticity.",
    details: [
      "Aim for at least 8 glasses (64 oz) of water per day",
      "Increase intake on active days or after treatment sessions",
      "Add natural flavor with lemon, cucumber, or berries",
      "Monitor your hydration by checking urine color — pale yellow is ideal",
    ],
  },
  {
    title: "Balanced Eating",
    icon: Salad,
    description:
      "A nutrient-rich diet fuels your body, supports your contouring results, and keeps your energy levels consistent throughout the day. Focus on whole foods and mindful portions.",
    details: [
      "Fill half your plate with fruits and vegetables",
      "Choose lean proteins like chicken, fish, or legumes",
      "Include healthy fats from avocado, nuts, and olive oil",
      "Minimize processed foods and added sugars",
    ],
  },
  {
    title: "Movement",
    icon: Activity,
    description:
      "Regular physical activity — even gentle movement — keeps your muscles engaged, improves circulation, and enhances the effects of body contouring treatments over time.",
    details: [
      "Aim for 30 minutes of moderate activity most days",
      "Walking, yoga, and stretching are excellent options",
      "Strength training complements body contouring beautifully",
      "Listen to your body and rest when needed",
    ],
  },
];

const HYDRATION_IMAGE = "https://media.base44.com/images/public/69ea7709def5ae18fa5c04eb/91762fa1f_generated_f9963207.png";
const EATING_IMAGE = "https://media.base44.com/images/public/69ea7709def5ae18fa5c04eb/63d5f6067_generated_ce6f69e7.png";
const MOVEMENT_IMAGE = "https://media.base44.com/images/public/69ea7709def5ae18fa5c04eb/58cca28e5_generated_23262f20.png";

export default function WellnessTips() {
  const images = [HYDRATION_IMAGE, EATING_IMAGE, MOVEMENT_IMAGE];

  return (
    <div>
      {/* Hero */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <SectionHeading
            label="Wellness Tips"
            title="Nourish Your Body & Mind"
            description="Simple, evidence-based wellness habits to support your body contouring journey and enhance your overall quality of life."
          />
        </div>
      </section>

      {/* Tips */}
      <section className="pb-24 lg:pb-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-10 space-y-20">
          {tips.map((tip, i) => (
            <RevealOnScroll key={tip.title}>
              <div
                className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center`}
              >
                <div className={i % 2 === 1 ? "lg:order-2" : ""}>
                  <img
                    src={images[i]}
                    alt={tip.title}
                    className="w-full rounded-[2rem] object-cover aspect-square shadow-lg"
                  />
                </div>
                <div className={i % 2 === 1 ? "lg:order-1" : ""}>
                  <div className="w-14 h-14 rounded-full bg-secondary flex items-center justify-center mb-5">
                    <tip.icon className="w-6 h-6 text-accent" />
                  </div>
                  <h3 className="font-heading text-2xl sm:text-3xl font-semibold text-foreground mb-4">
                    {tip.title}
                  </h3>
                  <p className="font-body text-base text-muted-foreground leading-relaxed mb-6">
                    {tip.description}
                  </p>
                  <ul className="space-y-3">
                    {tip.details.map((d) => (
                      <li
                        key={d}
                        className="font-body text-sm text-foreground/70 flex items-start gap-3"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0" />
                        {d}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </RevealOnScroll>
          ))}
        </div>
      </section>

      {/* External resource */}
      <section className="py-24 lg:py-32 bg-secondary/30">
        <div className="max-w-3xl mx-auto px-6 lg:px-10 text-center">
          <RevealOnScroll>
            <p className="font-body text-xs tracking-[0.3em] uppercase text-primary mb-4">
              Helpful Resource
            </p>
            <h2 className="font-heading text-3xl sm:text-4xl font-semibold text-foreground mb-4">
              Build Your Plate
            </h2>
            <p className="font-body text-base text-muted-foreground leading-relaxed mb-8 max-w-lg mx-auto">
              The USDA's MyPlate tool is a great resource for building balanced
              meals and understanding proper nutrition. We recommend it to all
              our clients as a helpful wellness companion.
            </p>
            <a
              href="https://www.myplate.gov"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 font-body text-sm font-medium bg-accent text-accent-foreground rounded-full px-8 py-4 hover:bg-accent/90 transition-all duration-300 shadow-lg shadow-accent/20"
            >
              Visit MyPlate.gov
              <ExternalLink className="w-4 h-4" />
            </a>
          </RevealOnScroll>
        </div>
      </section>
    </div>
  );
}