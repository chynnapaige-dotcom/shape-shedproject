import React from "react";
import SectionHeading from "../components/shared/SectionHeading";
import RevealOnScroll from "../components/shared/RevealOnScroll";

const gallery = [
  {
    image: "https://media.base44.com/images/public/user_69ea6b532f35d3933185bec1/452635969_beforeafter1.jpg",
    label: "Abs Contouring — 60 Day Results",
  },
  {
    image: "https://media.base44.com/images/public/user_69ea6b532f35d3933185bec1/444df2a3e_beforeafter2.jpg",
    label: "Core Toning — 60 Day Results",
  },
  {
    image: "https://media.base44.com/images/public/user_69ea6b532f35d3933185bec1/3d95991e8_beforeafter3.jpg",
    label: "Body Sculpting — 60 Day Results",
  },
  {
    image: "https://media.base44.com/images/public/user_69ea6b532f35d3933185bec1/99bd3f88e_glute.jpg",
    label: "Glute Lift — Progress",
  },
];

export default function BeforeAfter() {
  return (
    <div>
      {/* Hero */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <SectionHeading
            label="Transformations"
            title="Real Progress, Real People"
            description="Browse our gallery of client results. Every journey is unique and individual results may vary. These images showcase the potential of consistent non-invasive body contouring sessions."
          />
        </div>
      </section>

      {/* Gallery */}
      <section className="pb-24 lg:pb-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {gallery.map((item, i) => (
              <RevealOnScroll key={item.label} delay={i * 0.1}>
                <div className="rounded-[2rem] overflow-hidden border border-secondary shadow-sm hover:shadow-lg transition-shadow duration-300">
                  <img
                    src={item.image}
                    alt={item.label}
                    className="w-full aspect-[4/3] object-cover"
                  />
                  <div className="p-6 bg-background">
                    <p className="font-heading text-lg font-semibold text-foreground">
                      {item.label}
                    </p>
                  </div>
                </div>
              </RevealOnScroll>
            ))}
          </div>

          <RevealOnScroll>
            <div className="mt-16 bg-secondary/40 rounded-[2rem] p-8 lg:p-12 text-center">
              <p className="font-heading text-xl font-semibold text-foreground mb-3">
                Disclaimer
              </p>
              <p className="font-body text-sm text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                Individual results may vary. The before and after images shown
                represent real client progress and are not guaranteed outcomes.
                Factors such as body type, lifestyle, and consistency can affect
                results. Always consult with a professional before starting any
                new wellness or body contouring program.
              </p>
            </div>
          </RevealOnScroll>
        </div>
      </section>
    </div>
  );
}