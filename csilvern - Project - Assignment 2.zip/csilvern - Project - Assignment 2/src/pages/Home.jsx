import React from "react";
import HeroSection from "../components/home/HeroSection";
import AboutSection from "../components/home/AboutSection";
import FeaturedServicesSection from "../components/home/FeaturedServicesSection";
import BeforeAfterPreview from "../components/home/BeforeAfterPreview";
import WellnessTipsPreview from "../components/home/WellnessTipsPreview";
import VideoSection from "../components/home/VideoSection";
import CTASection from "../components/home/CTASection";

const HERO_IMAGE = "https://media.base44.com/images/public/69ea7709def5ae18fa5c04eb/e89ea0c52_generated_6deadd05.png";
const ABOUT_IMAGE = "https://media.base44.com/images/public/69ea7709def5ae18fa5c04eb/e304b0fe8_generated_40cd009c.png";

export default function Home() {
  return (
    <div>
      <HeroSection heroImage={HERO_IMAGE} />
      <AboutSection aboutImage={ABOUT_IMAGE} />
      <FeaturedServicesSection />
      <BeforeAfterPreview />
      <WellnessTipsPreview />
      <VideoSection />
      <CTASection />
    </div>
  );
}