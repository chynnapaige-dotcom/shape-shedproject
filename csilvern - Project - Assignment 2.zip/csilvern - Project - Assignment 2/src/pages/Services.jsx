import React from "react";
import { Link } from "react-router-dom";
import { Zap, Heart, MessageCircle } from "lucide-react";
import SectionHeading from "../components/shared/SectionHeading";
import RevealOnScroll from "../components/shared/RevealOnScroll";

const services = [
  {
    title: "Emslim Abs",
    description:
      "Our Emslim Abs treatment uses high-intensity focused electromagnetic energy to stimulate powerful muscle contractions in the abdomen. In just one 30-minute session, your muscles experience the equivalent of thousands of crunches — building strength, definition, and tone without surgery or downtime.",
    icon: Zap,
    image: "https://media.base44.com/images/public/user_69ea6b532f35d3933185bec1/a8d4ea32b_max5.jpg",
    benefits: ["Core strengthening", "Fat reduction", "Improved posture", "No downtime"],
  },
  {
    title: "Emslim Glutes",
    description:
      "Shape and lift your glutes with our advanced body contouring technology. The Emslim Glutes treatment triggers deep muscle contractions that are impossible to achieve through exercise alone, helping you build natural curves and muscle definition in just 30 minutes per session.",
    icon: Heart,
    image: "https://media.base44.com/images/public/user_69ea6b532f35d3933185bec1/99bd3f88e_glute.jpg",
    benefits: ["Muscle toning", "Natural lift", "Curve definition", "Quick sessions"],
  },
  {
    title: "Consultation",
    description:
      "Every transformation begins with understanding. Our personalized consultations give you the space to discuss your goals, learn about our technology, ask questions, and receive a custom plan designed specifically for your body and lifestyle. There's no pressure — just honest, supportive guidance.",
    icon: MessageCircle,
    image: "https://media.base44.com/images/public/user_69ea6b532f35d3933185bec1/089c07195_machine.jpg",
    benefits: ["Goal setting", "Custom plan", "No obligation", "Expert guidance"],
  },
];

export default function Services() {
  return (
    <div>
      {/* Hero */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <SectionHeading
            label="Our Services"
            title="The Performance Suite"
            description="Advanced non-invasive body contouring and wellness services designed to help you look and feel your absolute best — with zero downtime."
          />
        </div>
      </section>

      {/* Service cards */}
      <section className="pb-24 lg:pb-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-10 space-y-20">
          {services.map((service, i) => (
            <RevealOnScroll key={service.title}>
              <div
                className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${
                  i % 2 === 1 ? "lg:flex-row-reverse" : ""
                }`}
              >
                <div className={i % 2 === 1 ? "lg:order-2" : ""}>
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full rounded-[2rem] object-cover aspect-[4/3] shadow-lg"
                  />
                </div>
                <div className={i % 2 === 1 ? "lg:order-1" : ""}>
                  <div className="w-14 h-14 rounded-full bg-secondary flex items-center justify-center mb-5">
                    <service.icon className="w-6 h-6 text-accent" />
                  </div>
                  <h3 className="font-heading text-2xl sm:text-3xl font-semibold text-foreground mb-4">
                    {service.title}
                  </h3>
                  <p className="font-body text-base text-muted-foreground leading-relaxed mb-6">
                    {service.description}
                  </p>
                  <div className="flex flex-wrap gap-3">
                    {service.benefits.map((b) => (
                      <span
                        key={b}
                        className="font-body text-xs bg-secondary text-foreground/70 rounded-full px-4 py-2"
                      >
                        {b}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </RevealOnScroll>
          ))}
        </div>
      </section>

      {/* Service comparison table */}
      <section className="py-24 lg:py-32 bg-secondary/30">
        <div className="max-w-4xl mx-auto px-6 lg:px-10">
          <SectionHeading
            label="At a Glance"
            title="Service Comparison"
            description="A quick overview of our core offerings to help you find the right fit."
          />

          <RevealOnScroll>
            <div className="bg-background rounded-[2rem] overflow-hidden shadow-sm">
              <table className="w-full font-body text-sm">
                <thead>
                  <tr className="border-b border-secondary">
                    <th className="text-left font-heading text-base font-semibold text-foreground px-8 py-5">
                      Service
                    </th>
                    <th className="text-left font-heading text-base font-semibold text-foreground px-8 py-5">
                      Target Area
                    </th>
                    <th className="text-left font-heading text-base font-semibold text-foreground px-8 py-5">
                      Session Length
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-secondary/60">
                    <td className="px-8 py-5 font-medium text-foreground">Emslim Abs</td>
                    <td className="px-8 py-5 text-muted-foreground italic">Abdomen</td>
                    <td className="px-8 py-5 text-primary">30 minutes</td>
                  </tr>
                  <tr className="border-b border-secondary/60">
                    <td className="px-8 py-5 font-medium text-foreground">Emslim Glutes</td>
                    <td className="px-8 py-5 text-muted-foreground italic">Glutes</td>
                    <td className="px-8 py-5 text-primary">30 minutes</td>
                  </tr>
                  <tr>
                    <td className="px-8 py-5 font-medium text-foreground">Consultation</td>
                    <td className="px-8 py-5 text-muted-foreground italic">Personalized Goals</td>
                    <td className="px-8 py-5 text-primary">20 minutes</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </RevealOnScroll>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 lg:py-32">
        <div className="max-w-3xl mx-auto px-6 lg:px-10 text-center">
          <RevealOnScroll>
            <h2 className="font-heading text-3xl sm:text-4xl font-semibold text-foreground mb-6">
              Ready to get started?
            </h2>
            <p className="font-body text-base text-muted-foreground mb-8 leading-relaxed">
              Book a free consultation to discuss your goals and learn which service
              is right for you.
            </p>
            <Link
              to="/contact"
              className="inline-flex items-center font-body text-sm font-medium bg-accent text-accent-foreground rounded-full px-10 py-4 hover:bg-accent/90 transition-all duration-300 shadow-lg shadow-accent/20"
            >
              Request a Consultation
            </Link>
          </RevealOnScroll>
        </div>
      </section>
    </div>
  );
}